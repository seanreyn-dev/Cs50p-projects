def main():
  camelcase = input("camelCase: ")
  scase = ""
  for c in camelcase:
    if camelcase.isupper():
      scase += "_" + c.lower()
    else:
      scase += c
    print(scase)

main()

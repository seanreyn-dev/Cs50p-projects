faces = input("Input something ")

faces = faces.replace(":)","🙂").replace(":(","🙁")

print(faces)

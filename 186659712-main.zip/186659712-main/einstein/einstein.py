einstein = input("M: ")
einstein = int(einstein) * 300000000 ** 2
print(f"E: {einstein}")

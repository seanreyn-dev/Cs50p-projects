x = int(input("What is x? "))
y = int(input("What is y? "))

if x != y:
    print("x is not equal to y")
else:
    print("x is equal to y")

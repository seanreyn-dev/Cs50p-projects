playback = input("Say something ")
playback = playback.replace(" ", "...")

print(playback)

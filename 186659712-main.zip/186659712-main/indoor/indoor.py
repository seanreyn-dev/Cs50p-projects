indoor = input("Input something ")
indoor = indoor.lower()

print(indoor)


def main():
    meal = input("What time is it? ")
    time_in_hours = convert (meal)
    if  7 <= time_in_hours <= 8:
        print("breakfast time")
    elif  12 <= time_in_hours <= 13:
        print("lunch time")
    elif  18 <= time_in_hours <= 19:
        print("dinner time")


def convert(time):
    hours, minutes = time.split(":")
    hours = float(hours)
    minutes = float(minutes) / 60
    return hours + minutes

if __name__ == "__main__":
    main()


def main():
    file = input("File name: ").lower()
    if file.endswith(".jpeg") or file.endswith(".jpg"):
        print("image/jpeg")
    elif file.endswith(".gif"):
        print("image/gif")
    elif file.endswith(".png"):
        print("image/png")
    elif file.strip().endswith(".pdf"):
        print("application/pdf")
    elif file.endswith(".txt"):
        print("text/plain")
    elif file.endswith(".zip"):
        print("application/zip")
    else:
        print("application/octet-stream")

main()
